package com.gd.icbc.dutydeal.base;

import android.app.Application;
import android.text.format.DateFormat;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.blankj.utilcode.util.Utils;
import com.gd.icbc.dutydeal.utils.GrgLog;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyApplication extends Application implements Thread.UncaughtExceptionHandler{

    // 建立请求队列
    public static RequestQueue mQueue;

    public static String LOG_PATH = "";

    public static final String PARENT_FILE_PATH = android.os.Environment.getExternalStorageDirectory().getPath()
            + "/dutydeal";

    private static String unDutyBeginTime;//非值班开始时间
    private static String unUnDutyEndTime;//非值班结束时间
    private static String sysTimeStr;//当前系统时间
    private static int dutyingInterval;

    @Override
    public void onCreate() {
        super.onCreate();
        unDutyBeginTime = "15:00:00";
        unUnDutyEndTime = "18:00:00";
        dutyingInterval = 15*60;
        Date sysTime = new Date();

        sysTimeStr = DateFormat.format("HH:mm:ss", sysTime).toString();//时间显示格式
        if(mQueue == null){
            mQueue = Volley.newRequestQueue(getApplicationContext());
        }

        Utils.init(this);

        LOG_PATH = PARENT_FILE_PATH + "/log/" + new SimpleDateFormat(GrgLog.DATE_FORMAT).format(new Date());

        GrgLog.init(LOG_PATH);

        Thread.setDefaultUncaughtExceptionHandler(this);


    }

    public static RequestQueue getHttpQueue() {
        return mQueue;
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        if (e == null) {
            return;
        }
        GrgLog.e("DutyDeal", "uncaughtException", e);
    }
}
