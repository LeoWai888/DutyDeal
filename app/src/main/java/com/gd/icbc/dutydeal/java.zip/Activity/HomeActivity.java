package com.gd.icbc.dutydeal.Activity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.speech.tts.TextToSpeech;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.support.v7.widget.SnapHelper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.detect.ui.AliveActivity;
import com.gd.icbc.dutydeal.R;
import com.gd.icbc.dutydeal.base.BaseActivity;
import com.gd.icbc.dutydeal.config.Settings;
import com.gd.icbc.dutydeal.config.constants;
import com.gd.icbc.dutydeal.contract.HomeContract;
import com.gd.icbc.dutydeal.json.DutyingPeople;
import com.gd.icbc.dutydeal.json.ParamObj;
import com.gd.icbc.dutydeal.json.SignPeople;
import com.gd.icbc.dutydeal.json.TimeDownBean;
import com.gd.icbc.dutydeal.presenter.HomePresenter;
import com.gd.icbc.dutydeal.utils.CountDownAdapter;
import com.gd.icbc.dutydeal.utils.ImageHelper;
import com.gd.icbc.dutydeal.utils.Mp3Play;
import com.gd.icbc.dutydeal.utils.TimeUtils;
import com.gd.icbc.dutydeal.utils.Voice;
import com.gd.icbc.dutydeal.utils.CountDownAdapter.SpacesItemDecoration;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeActivity extends BaseActivity implements View.OnClickListener, HomeContract.View {

    @BindView(R.id.systemTime)
    TextView systemTime;
    @BindView(R.id.systemTime_Rl)
    RelativeLayout systemTimeRl;

    @BindView(R.id.recycle_list_view)
    RecyclerView recycleListView;
    @BindView(R.id.Tocamera)
    ImageView Tocamera;
    @BindView(R.id.signInfo_ly)
    RelativeLayout signInfoLy;
    @BindView(R.id.before_sign_tv)
    TextView beforeSignTv;
    @BindView(R.id.before_sign_time_tv)
    TextView beforeSignTimeTv;
    @BindView(R.id.before_sign_rl)
    RelativeLayout beforeSignRl;
    private TextToSpeech tts;
    private AlertDialog mDialog;//等待对话框
    private HomeContract.Presenter mPresenter;
    public String unDutyBeginTime="2018-12-21 00:00:00";//非值班开始时间
    public String unUnDutyEndTime="2018-12-21 01:00:00";//非值班结束时间
    public String sysTimeStr;//当前系统时间
    public int dutyingInterval;//每次刷脸间隔
    public int firstDutyCountdown;//首次刷脸的倒计时
    private List<TimeDownBean> mTimeDownBeanList=new ArrayList<>();
    private CountDownAdapter mCountDownAdapter;
    private boolean isPermissionAccessed = true;
    private static final int PERMISSION_REQUEST_CODE = 0;  //申请权限请求码
    private int type;// 用户操作的业务类型
    private byte[] image;
    private Voice mvoice;
    private Mp3Play mMp3Play;
    private boolean playNoneMp3;
    private boolean playOneMp3;
    private boolean playTwoMp3;
    private boolean inCamera;
    private MediaPlayer mMediaPlayer = null;
    private int SpanCounts;
    private final int mSpanShowSize = 4;

    long useTimeBefore;
    long useTime = 305;

    Properties prop = null;

    private String FREE_TIME;
    private String RING_TIME;
    private String ON_TIME="00:00:00";
    private String OFF_TIME="00:00:00";
    private String ARAENO="";
    /*
    1、在非值班時間顯示系統時間；
     */
    class TimeThread extends Thread {
        @Override
        public void run() {
            do {
                try {
                    sysTimeStr = TimeUtils.getCurrentTimeString();
                    if (inCamera) {
                    } else if ((sysTimeStr.compareTo(unDutyBeginTime)>=0) && (sysTimeStr.compareTo(unUnDutyEndTime) < 0)) {
                        onSendMsgs(R.id.unDuty_state);// 每隔1秒发送一个msg给mHandler
                    }
                    //else if (mTimeDownBeanList.isEmpty() || mTimeDownBeanList.size() == 0) {
                    else if (mTimeDownBeanList.size() == 0 ) {
                    onSendMsgs(R.id.NoneDuty_state);
                    } else if (mTimeDownBeanList.size() == 1) {
                        onSendMsgs(R.id.FristDuty_state);
                    } else {
                        onSendMsgs(R.id.SecondDuty_state);
                    }
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (true);
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initProp();

        ButterKnife.bind(this);
        mvoice = new Voice(this);
        mMp3Play = new Mp3Play(this);
        initEvents();
        String araeNo = getPropValue("ARAE_NO");
        if ((araeNo!="") || (araeNo!=null)) {
            ARAENO = araeNo;
            mPresenter = new HomePresenter(this);
            mPresenter.loadParam();
            //loadHomeData(ON_TIME,OFF_TIME);
            //
        }else {
//            弹出配置框,修改配置文件
            onSendMsgs(R.id.ccnfig_state);
        }
    }

    private void initProp(){
        prop = new Properties();

        try {
            String config_file = constants.CONFIG_FILE;
            InputStream in = getApplicationContext().getAssets().open(config_file);  //打开assets目录下的config.properties文件
            prop.load( new InputStreamReader(in,"utf-8"));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    //读取配置文件
    private String getPropValue(String key){
        String value  = prop.getProperty(key);
        return value;
    }

    //修改配置文件
    private String setPropValue(String key,String value) {
        try {
            prop.setProperty (key,value);
            File file = new File("file:///android_asset/"+constants.CONFIG_FILE);
            OutputStream fos = new FileOutputStream(file);
            prop.store(fos, "Update '" + key + "' value");
            fos.flush();
            return value;
        } catch (Exception e1) {
            return null;
        } finally {

        }
    }

    /*
    1、读取初始化数据包括:1、参数（开始时间、结束时间、考勤间隔时间）
    2、读取正在值班人员的最新耍脸考勤数据
    */
    private void loadHomeData(String onTime,
                              String offTime,
                              String freeTime,
                              String ringTime,
                              String araeNo) {
        /*
        1.初始化系统设置，这些设置应该从服务器获取
        包括
        值班开始时间（unUnDutyEndTime）
        值班结束时间（unDutyBeginTime）
        刷脸时间间隔（dutyingInterval）
        值班开始后首次刷脸的缓冲时间 （firstDutyCountdown）
        */

        sysTimeStr = TimeUtils.getCurrentTimeString();   //系统日期
        ON_TIME = onTime;
        OFF_TIME = offTime;
        unDutyBeginTime = sysTimeStr.substring(0, 11) + ON_TIME;   //日期加时间：2018-12-21 00:00:00
        unUnDutyEndTime = sysTimeStr.substring(0, 11) + OFF_TIME;   //日期加时间：2018-12-21 00:00:00
        Log.e("undutybegintime", unDutyBeginTime+"; "+unUnDutyEndTime);


        dutyingInterval = Integer.parseInt(freeTime) * 60;
        firstDutyCountdown = 15 * 60;
        /*
        2.初始化上次刷脸情况数据
        上次刷脸情况
        读取正在值班人员的最新刷脸考勤数据
        每个考勤人显示信息（照片、上一次刷脸考勤时间、距离上一次刷脸考勤的间隔时间
        (假设考勤间隔为1分钟60秒)显示=60-（当前时间-上次刷脸时间）,当它为负值时，显示绝对值，同时变红色报警状态
        */

        mPresenter.loadDutyingPeoples("02001");
            /*
            //读取正在值班人员的最新耍脸考勤数据
            每个考勤人显示信息（照片、上一次刷脸考勤时间、距离上一次刷脸考勤的间隔时间
            (假设考勤间隔为1分钟60秒)显示=60-（当前时间-上次刷脸时间）,当它为负值时，显示绝对值，同时变红色报警状态
            */

        playNoneMp3 = false;
        playOneMp3 = false;
        playTwoMp3 = false;
        inCamera = false;
    }

    /*
    1、根据当前时间显示内容，状态1：在非值班考勤时间内，显示系统时间。
                            状态2：在考勤时间内，显示已考勤人列表，每个考勤人显示信息（照片、上一次刷脸考勤时间、距离上一次刷脸考勤的间隔时间(假设考勤间隔为1分钟)
                            =60-（当前时间-上次刷脸时间）,当它为正值时作为倒计时时间 数字- -、当它为负值取正 数字++
    2、视图需要
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initViews() {
        /*
        初始化recycleListView 并指定mTimeDownBeanList为recycleListView展示的数据，其二者用mCountDownAdapter进行适配
        开启线程进行每秒一次的页面刷新
         */
        SnapHelper snapHelper=new LinearSnapHelper();
        snapHelper.attachToRecyclerView(recycleListView);

        LinearLayoutManager ms=new LinearLayoutManager(this) ;
        ms.setOrientation(LinearLayoutManager.HORIZONTAL);
        mCountDownAdapter = new CountDownAdapter(this, mTimeDownBeanList);

        int space=8;
        recycleListView.setHasFixedSize(true);
        recycleListView.setLayoutManager(ms);
        recycleListView.addItemDecoration(new SpacesItemDecoration(space));


        recycleListView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        ((SimpleItemAnimator) recycleListView.getItemAnimator()).setSupportsChangeAnimations(false);
        recycleListView.setAdapter(mCountDownAdapter);
        new TimeThread().start();
    }

    @Override
    protected void onMsgResult(Message msg) {
        super.onMsgResult(msg);
        switch (msg.what) {
            case R.id.wait_state:
                to_waitState();
                break;
            case R.id.ccnfig_state:
                to_confProp();
                break;
            case R.id.unDuty_state:
                to_unDuty();
                break;
            case R.id.NoneDuty_state:
                to_NoneDuty();
                break;
            case R.id.FristDuty_state:
                to_FristDuty();
                break;
            case R.id.SecondDuty_state:
                to_SecondDuty();
                break;
        }
    }

    private void to_confProp() {
        //參數配置處理
    }

    private void to_waitState() {
        mPresenter.loadParam();
    }

    private void to_SecondDuty() {
        systemTimeRl.setVisibility(View.GONE);
        signInfoLy.setVisibility(View.VISIBLE);
        beforeSignRl.setVisibility(View.GONE);
        refreshBeanList(true);
    }

    private void to_FristDuty() {
        systemTimeRl.setVisibility(View.GONE);
        signInfoLy.setVisibility(View.VISIBLE);
        beforeSignRl.setVisibility(View.VISIBLE);

        String noneDutyEndTime = TimeUtils.getTimeAfterSeconds(unUnDutyEndTime, firstDutyCountdown);
        //距离首次打卡截止的剩余时间（单位：秒）
        long noneDutyEndCountdown = TimeUtils.differenceSenconds(sysTimeStr, noneDutyEndTime);
        if (noneDutyEndCountdown > 0) {
            beforeSignTv.setText("还有一人没考勤签到，倒计时");
            mMp3Play.play_release();
            playOneMp3 = false;
        } else {
            beforeSignTv.setText("还有一人没考勤签到，已超时");
            noneDutyEndCountdown = -noneDutyEndCountdown;
            if (!playOneMp3) {
                mMp3Play.play(this, R.raw.super_mary);
                playOneMp3 = true;
            }
        }
        beforeSignTimeTv.setText(TimeUtils.CountDownSenconds(noneDutyEndCountdown));
        refreshBeanList(!playOneMp3);
    }

    private void to_NoneDuty() {
        systemTimeRl.setVisibility(View.GONE);
        signInfoLy.setVisibility(View.VISIBLE);
        beforeSignRl.setVisibility(View.VISIBLE);

        String noneDutyEndTime = TimeUtils.getTimeAfterSeconds(unUnDutyEndTime, firstDutyCountdown);
        //距离首次打卡截止的剩余时间（单位：秒）
        long noneDutyEndCountdown = TimeUtils.differenceSenconds(sysTimeStr, noneDutyEndTime);
        if (noneDutyEndCountdown > 0) {
            beforeSignTv.setText("还没人考勤签到，倒计时");

            beforeSignTimeTv.setText(TimeUtils.CountDownSenconds(noneDutyEndCountdown));
            long hour = (int) (noneDutyEndCountdown / 3600);
            long min = (noneDutyEndCountdown / 60) % 60;
            long second = noneDutyEndCountdown % 60;
            if (min <= 5) {
                if (hour == 0 && min > 0 && (second == 0 || second == 30)) {
                    //大于一分钟，每30秒播报
                    mvoice.speak("距离下次打卡时间还有" + min + "分钟");
                } else if (hour == 0 && min == 0 && (second == 0 || second == 20 || second == 40)) {
                    //最后一分钟，每20秒播报
                    mvoice.speak(String.valueOf(second) + "秒");
                }
            }
            mMp3Play.play_release();
            playNoneMp3 = false;
        } else {
            if (!playNoneMp3) {
                mMp3Play.play(this, R.raw.super_mary);   //2018
                playNoneMp3 = true;
            }
            beforeSignTv.setText("还没人考勤签到，已超时");
            beforeSignTimeTv.setText(TimeUtils.CountDownSenconds(-noneDutyEndCountdown));
        }
    }

    private void refreshBeanList(boolean needPlayMp3) {
        boolean playMp3 = false;
        for (TimeDownBean timeDownBean : mTimeDownBeanList) {
            String nextDutyTimeString = TimeUtils.getTimeAfterSeconds(timeDownBean.getLastTime(), dutyingInterval);
            long nextDutyCountdown = TimeUtils.differenceSenconds(sysTimeStr, nextDutyTimeString);
            timeDownBean.setUseTime(nextDutyCountdown);
            if (nextDutyCountdown < 0) {
                playMp3 = true;
            }
        }
        if (needPlayMp3) {
            if (playMp3) {
                mMp3Play.play(this, R.raw.super_mary);   //2018
            } else {
                mMp3Play.play_release();

            }
        }
        mCountDownAdapter.notifyDataSetChanged();
    }

    //進入值班時間或進入非值班時間,显示系统时间
    private void to_unDuty() {
        systemTimeRl.setVisibility(View.VISIBLE);
        signInfoLy.setVisibility(View.GONE);
        beforeSignRl.setVisibility(View.GONE);
        systemTime.setText(sysTimeStr.substring(11)); //更新时间
    }



    private void initEvents() {
        Tocamera.setOnClickListener(this);
    }

    /*
    1、一个刷脸button事件：点击激活活体拍照
    2、每个值班人员的退出考勤button事件，点击退出考勤（条件判断：列表中不能少于二人）
    3、倒计时报警消息处理事件
     */
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Tocamera) {
            if (!isPermissionAccessed) {
                checkPremissions();
//                return;
            }
        }

        if (v.getId() == R.id.Tocamera) {
            inCamera = true;
            mMp3Play.play_release();
            final Intent intent = new Intent(HomeActivity.this, AliveActivity.class);
            //传递动作序列的int数组
            intent.putExtra(AliveActivity.EXTRA_SEQUENCES, Settings.INSTANCE.getSequencesInt(getApplicationContext()));
            //传递是否录制视频的参数
            intent.putExtra(AliveActivity.EXTRA_IS_RECODING, true);
            //传递录制视频的持续时间参数，不传开启视频录制的情况下默认10秒
            intent.putExtra(AliveActivity.EXTRA_RECODING_DURATION, 10);
            //传递单个动作超时时间参数，单位为秒
            intent.putExtra(AliveActivity.EXTRA_MOTION_TIMEOUT, 10);
            //视频保存路径（不传默认未外存储根目录）
            type = constants.TYPE_AUTHENITCATION;
            startActivityForResult(intent, 1);
        }
    }

    private static boolean isMarshmallow() {
        return Build.VERSION.SDK_INT >= 23;
    }

    private void checkPremissions() {
        if (isMarshmallow()) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                isPermissionAccessed = false;
                if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) || shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                }

                requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
            } else {
                //permission is already available
            }
        }
    }

    @Override
    public void setPresenter(HomeContract.Presenter presenter) {
        this.mPresenter = presenter;
    }

    @Override
    public void showLoding() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.e("BACS", "mDialog.show()");
                mDialog.show();
            }
        });
    }

    @Override
    public void hodeLoding() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.e("BACS", "mDialog.dismiss()");
                mDialog.dismiss();
            }
        });
    }

    /*
    读取服务端参数异常，3秒重试
     */
    @Override
    public void showError(String msg) {
        ToastUtils.showLong(msg);
        onRemoveMsgs(R.id.wait_state);
        onSendMsgDelayed(R.id.wait_state, null, 3000);
    }
    /*
    MVP 的V实现过程
     */
    @Override
    public void showDutyingPeople(List<DutyingPeople.DutyingDataBean> dutyingData) {
        //在值班开始第一个时间间隔进行数据初始化，没有人签到时
        //=当前时间-非值班结束时间
        if (dutyingData != null) {
            for (DutyingPeople.DutyingDataBean dutyingDataBean : dutyingData) {
                long initTimeDownSencond = dutyingInterval - TimeUtils.differenceSenconds(dutyingDataBean.getPunchTime(), sysTimeStr);
                TimeDownBean timeDownBean = new TimeDownBean(dutyingDataBean.getPunchTime(), initTimeDownSencond, dutyingDataBean.getEmpName()
                        , dutyingDataBean.getEmpPhoto());
                mTimeDownBeanList.add(timeDownBean);   //添加数据
            }
        }
//        mCountDownAdapter.notifyDataSetChanged(); //这里不能notify 否则直接闪退
    }

    @Override
    public void showSignPeople(SignPeople signPeopleData) {
        if (signPeopleData == null){
//            Toast.makeText(this,"考勤失败，请重试！！" ,Toast.LENGTH_LONG ).show();
            Log.e("BACS:", "考勤失败，请重试！！");
        }else {
            if (signPeopleData.getResult().equals("1") && signPeopleData.getRetCode().equals("0")) {
                boolean flag = false;  //判断是否插入的标志，未插入为false
                String currentTimeString = TimeUtils.getCurrentTimeString();
                long useTime = dutyingInterval - TimeUtils.differenceSenconds(currentTimeString, sysTimeStr);
                TimeDownBean timeDownBean = new TimeDownBean(currentTimeString, useTime, signPeopleData.getUserName(),signPeopleData.getUserPhoto());
                for (int i = 0; i < mTimeDownBeanList.size(); i++) {
                    if ((signPeopleData.getUserName().equals(mTimeDownBeanList.get(i).getContent())))   //判断是否存在同名情况
                    {
                        mTimeDownBeanList.set(i, timeDownBean);   //存在同名，在对应位置刷新列表项目
                        flag = true;   //修改插入标志
                    }
                }
                //不存在同名，在后面添加列表新项
                if (!flag) {
                    mTimeDownBeanList.add(timeDownBean);
                    flag = true;
                }

                Log.e("更新列表:", "");

            } else {
                //弹出异常信息提示
               Toast.makeText(getApplicationContext(),"照片无法识别，请重试！！" ,Toast.LENGTH_LONG ).show();
            }
        }
    }


    //刷脸后显示列表信息
    @Override
    public String getPhotosData(byte[] image) {
        String ImageData = String.valueOf(ImageHelper.BitmapTo64(ImageHelper.bytes2Bimap(image)));
        Log.d("显示照片base64", ImageData);
        return ImageData;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void initParams(ParamObj params) {
        if (params!=null)
        {
            FREE_TIME=params.getFREE_TIME(); //登记周期
            RING_TIME=params.getRING_TIME(); //报警开始时间
            OFF_TIME=params.getOFF_TIME();//非值班开始时间
            ON_TIME=params.getON_TIME();//非值班结束时间
            Log.d("时间参数：", ON_TIME+"； "+OFF_TIME+"；"+RING_TIME+"; "+FREE_TIME);
            sysTimeStr = TimeUtils.getCurrentTimeString();
            if ((sysTimeStr.compareTo(unDutyBeginTime)>=0) && (sysTimeStr.compareTo(unUnDutyEndTime) < 0)) {
                loadHomeData(ON_TIME, OFF_TIME,FREE_TIME,RING_TIME,ARAENO);
            }
            initViews();
        }
        else {
            Log.d("BACS:","获取参数失败" );
            showError("获取参数失败！三秒后重试！");
            //弹出错误窗体，点击后退出应用
        }
    }

    //刷脸的代码
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            Intent intent = new Intent();
            intent.putExtra("img", data.getByteArrayExtra(AliveActivity.EXTRA_RESULT_IMG_DATA));
//			data.getStringExtra(AliveActivity.EXTRA_RESULT_VIDEO_DATA);// 获取录制的视频存储路径
            switch (type) {
                case constants.TYPE_AUTHENITCATION:
                    //可能出错在这里——是否可以直接接收
                    image = intent.getByteArrayExtra("img");
                    mPresenter.loadSignPeople(getPhotosData(image));
                    break;
                default:
                    break;
            }
//            startActivity(intent);
//            finish();
        } else if (resultCode == RESULT_CANCELED) {
            // 活体检测失败返回
        }
        inCamera = false;
    }

}