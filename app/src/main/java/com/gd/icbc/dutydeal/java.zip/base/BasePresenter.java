package com.gd.icbc.dutydeal.base;

/**
 * 规定Presenter必须要实现start方法
 */
public interface BasePresenter {
    void start();
}
