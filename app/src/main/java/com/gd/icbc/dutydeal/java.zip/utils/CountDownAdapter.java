package com.gd.icbc.dutydeal.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.gd.icbc.dutydeal.R;
import com.gd.icbc.dutydeal.json.TimeDownBean;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;


public class CountDownAdapter extends RecyclerView.Adapter {
    private Context mContext;
    private List<TimeDownBean> mTimeDownBeanList;
    private Voice mvoice;
//    private Mp3Play mMp3play;

    public CountDownAdapter(Context context, List<TimeDownBean> mTimeDownBeanList) {
        this.mContext = context;
        this.mTimeDownBeanList = mTimeDownBeanList;
//        startTime();
       //mvoice = new Voice(context);
//        mMp3play = new Mp3Play(context);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //View view = View.inflate(mContext, R.layout.list_item, null);
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false );
        return new ViewHolder(view);
    }

    //holder复用
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            ViewHolder viewHolder = (ViewHolder) holder;
            TimeDownBean timeDownBean = mTimeDownBeanList.get(position);
            viewHolder.contentTv.setText(timeDownBean.getContent());
            Bitmap bitmap=BitmapUtils.stringtoBitmap(timeDownBean.getPhoto());    //2018
            viewHolder.photoData.setImageBitmap(bitmap);   //设置图片
            try {
                setTime(viewHolder, position);

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    private void setTime(ViewHolder holder, int position) throws ParseException {
        TimeDownBean timeDownBean = mTimeDownBeanList.get(position);
//        if (timeDownBean.getUseTime() > 1000) {
        holder.timeTv.setVisibility(View.VISIBLE);
        long useTime = timeDownBean.getUseTime();
        setTimeShow(useTime, holder);
//            mMp3play.play_release();

    }

    @SuppressLint({"ResourceAsColor", "NewApi"})
    private void setTimeShow(long useTime, ViewHolder holder) {
        boolean isCountup = false;
        if (useTime < 0) {
            useTime = -useTime;
            isCountup = true;
        }
        int hour = (int) (useTime / 3600);
        int min = (int) (useTime / 60 % 60);
        int second = (int) (useTime % 60);
        int day = (int) (useTime / 3600 / 24);
        String strTime = String.format(Locale.CHINA, "%02d:%02d:%02d", hour, min, second);
        holder.timeTv.setText(strTime);
        holder.timeTv.setTextColor(Color.BLACK);
        if (hour == 0 && (min == 4 || min == 3)) {
            holder.itemView.setBackgroundResource(R.drawable.yellowitem);

        } else if (hour == 0 && (min >= 0 && min <= 2)) {
            holder.itemView.setBackgroundResource(R.drawable.reditem);

            if (hour == 0 && min > 0 && (second == 0 || second == 30) && !isCountup) {
              //  mvoice.speak("距离下次打卡时间还有" + min + "分钟");
            } else if (hour == 0 && min == 0 && (second == 0 || second == 20 || second == 40) && !isCountup)  //最后一分钟
            {
              //  mvoice.speak(String.valueOf(second) + "秒");
            }

        } else {
            holder.itemView.setBackgroundResource(R.drawable.greenitem);
        }
        if (isCountup) {
            //TODO:报警

//            play(mContext,R.raw.super_mary);
//            mMp3play.play(mContext,R.raw.super_mary);
//            holder.timeTv.setTextColor(Color.WHITE);
            //holder.itemView.setBackgroundColor(Color.parseColor("#FF0000"));
            holder.itemView.setBackgroundResource(R.drawable.reditem);

        }
//        mMp3play.play_release();
    }


    @Override
    public int getItemCount() {
        return mTimeDownBeanList != null ? mTimeDownBeanList.size() : 0;
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        private TextView contentTv;
        private TextView timeTv;
        private CircleImageView photoData;

        private ViewHolder(View itemView) {
            super(itemView);
            init(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (itemClickListener != null) {
                        itemClickListener.onItemClick(v, getLayoutPosition());
                    }
                }
            });
        }


        private void init(View itemView) {
            contentTv = (TextView) itemView.findViewById(R.id.content_tv);
            timeTv = (TextView) itemView.findViewById(R.id.time_tv);
            photoData=(CircleImageView)itemView.findViewById(R.id.registrar_img);

        }
    }

    //Android横向recycleView数据居中，从中间向两边展示
    /*
    @param num list的size，item的个数
    @param itemWight 每一个item的宽度，像素
    @param view 控件可以是recycleView
     */
//    private void setAncestralRecyclerCenterHor(int num, int itemWight, View view)
//    {
//        int interval = ScreenUtils.dp2px(4f,this); //每个item之间间隔的宽度
//        int totalHasWight= MyApplication.screenWith-num * (itemWight+interval);
//        if(totalHasWight>0)
//        {
//            view.setPadding((totalHasWight-interval)/2,0 ,totalHasWight/2 ,0 );
//        }
//        else {
//            view.setPadding(0,0,0,0  );
//        }
//    }

    //设置item间距的辅助类
    public static class SpacesItemDecoration extends RecyclerView.ItemDecoration
    {
        private  int space;
        public SpacesItemDecoration(int space)
        {
            this.space=space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view,RecyclerView parent, RecyclerView.State state)
        {
            outRect.left=space;
            outRect.right=space;
//            outRect.bottom=space;
//
//            if (parent.getChildAdapterPosition(view)==0)
//                outRect.left=space;
        }
    }
    //对外部暴漏点击事件接口
    public interface OnItemClickListener {
        void onItemClick(View v, int position);
    }

    public OnItemClickListener itemClickListener;

    public void setItemClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

}

